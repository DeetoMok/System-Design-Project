training set: 'generatedPoints1_100000.csv' in Test Problem Set 1
test set: 'generatedPoints1_100000.csv' in Test Problem Set 2
current AED data: 'Current AED Placement.xlsx'
candidate AED data: 'Singapore buildings locations.xlsx'

Mapping-subzone-planning area: map OHCA and AED into polygons
MCLP-Subzone: Perform MCLP mdoel at subzone level
PCM-Subzone: Perform PCM at subzone level
MultipleMCLP-subzone: Perform clustering and MCLP at subzone level
MultiplePCM-subzone: Perform clustering and PCM at subzone level
MCLP-Planning Area: Perform MCLP mdoel at planning-area level
MultipleMCLP-Planning Area: Perform clustering and MCLP at planning-area level
MultiplePCM-Planning Area: Perform clustering and PCM at planning-area level
AED Allocation and Analysis-WholeSG: Perform MCLP(cannot work), PCM (cannot work) 
and clustering-based MCLP and PCM on country wide data and obtain the training
and test results; obtain metrics of the current placement